<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Practice </title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    
    <div class="flex-container">

        <div class="header">     
               <?php include 'logo.inc.php' ?>         
               <?php include 'menu.inc.php' ?>	   
        </div>       
     
        <div class="about_me">
         
          <h1>  <?php  echo $p  ?> </h1>

            <div class="data">
                <div class="myImg">
                    <?php  echo '<img src="img/1.png">'; ?>                    
                </div>

                <div class="fullname">
                    <p> Иногда меня зовут 
                    <?php echo $name, ', но так как я коренной, ', $namecity,', то чаще меня зовут ', $surname . '<br>'; 
                          echo 'Родной город мой', ' ', $city; ?>                                      
                    </p> 
           
                    <p> Пока меня не ловили, но грозились, если поймают, закрыть меня на
                    <?php  echo $age;   ?>          
                    лет </p>
                    <p> Возможно, что-то да отложилось в памяти и через какое-то </p>
                    <p> время я смогу создать переменные и проделать простые операции с ними </p>
                </div>
            </div>

            <div class="knowledge">
                                   
                    <?php  include 'knowledge.inc.php'; ?>
                    <?php   echo $a, ' ', $b,  $c; ?> <br>
                                       
                    <?php
                        $a = 10;
                        $b = 20;
                        $c = $a + $b;
                        echo 'Примерно ', $c,' килограммовым';
                    ?>   <br>                
                     <?php
                        echo 'Но это не сильно критично и ', $d;
                    ?> 

            </div>
                    
            <div class="article">
                <p class="text">
                Rfrjq-nj yt gjyznysq ntrcn? levfk elfkbnm tuj bkb jcnfdbnm. D bnjut, gthtrhtcnzcz, elfkbk jn uht[f gjlfkmit!
                </p>
            </div>
        </div>

            <?php include 'footer.inc.php' ?>

    </div>


</body>
</html>
