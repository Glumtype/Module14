    
                <div class="logo"> 
                <img src="img/1.gif" alt="php">
                </div>                                                 
        