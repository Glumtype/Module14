<div class="footer">
            <h2>Мы думаем, что ознакомились с основами PHP!</h2>
        </div>