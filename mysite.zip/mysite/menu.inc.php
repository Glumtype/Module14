            <nav>
                <ul>
                    <li><a href="https://skillfactory.ru/" title="Все пути ведут в.."> About my studies </a></li>
                    <li><a href="https://skillfactory.ru/" title="Все пути ведут в.."> My portfolio </a></li>
                    <li><a href="https://skillfactory.ru/" title="Все пути ведут в.."> My articles </a></li>
                    <li><a href="https://skillfactory.ru/" title="Все пути ведут в.."> Links </a></li>
                    <li><a href="https://skillfactory.ru/" title="Все пути ведут в.."> Contacts </a></li>
                </ul>    
            </nav>